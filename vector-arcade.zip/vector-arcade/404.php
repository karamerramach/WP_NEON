<?php
/** 404 template. @package Vector_Arcade */
get_header();
?>
<main id="content" class="va-main">
	<div class="va-wrap">
		<div class="va-feature" style="max-width:850px;margin:0 auto;text-align:center">
			<div class="va-feature-content" style="margin-inline:auto">
				<span class="va-eyebrow"><?php esc_html_e( 'Error 404 / Sector not found', 'vector-arcade' ); ?></span>
				<h1 class="va-entry-title"><?php esc_html_e( 'GAME OVER?', 'vector-arcade' ); ?></h1>
				<p><?php esc_html_e( 'This page drifted beyond the map. Return to base or search the archive.', 'vector-arcade' ); ?></p>
				<a class="va-button" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to base', 'vector-arcade' ); ?></a>
				<div style="margin-top:24px"><?php get_search_form(); ?></div>
			</div>
		</div>
	</div>
</main>
<?php get_footer(); ?>
