<?php
/** Post card used in the homepage and archives. @package Vector_Arcade */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'va-post-card' ); ?>>
	<a class="va-card-media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
		<?php if ( has_post_thumbnail() ) : ?>
			<?php the_post_thumbnail( 'vector-arcade-card', array( 'loading' => 'lazy' ) ); ?>
		<?php else : ?>
			<span class="va-card-placeholder" aria-hidden="true"></span>
		<?php endif; ?>
	</a>
	<div class="va-card-body">
		<div class="va-card-meta"><?php vector_arcade_card_meta(); ?></div>
		<h2 class="va-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		<p class="va-card-excerpt"><?php echo esc_html( vector_arcade_card_excerpt() ); ?></p>
		<a class="va-card-read" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read transmission', 'vector-arcade' ); ?></a>
	</div>
</article>
