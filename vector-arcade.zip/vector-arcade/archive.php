<?php
/** Archive template. @package Vector_Arcade */
get_header();
?>
<main id="content" class="va-main">
	<div class="va-wrap">
		<header class="va-page-header"><span class="va-eyebrow"><?php esc_html_e( 'Archive signal', 'vector-arcade' ); ?></span><h1 class="va-page-title"><?php the_archive_title(); ?></h1><?php the_archive_description( '<div class="va-page-description">', '</div>' ); ?></header>
		<?php if ( have_posts() ) : ?>
			<div class="va-post-grid"><?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/content', 'card' ); endwhile; ?></div>
			<div class="va-pagination"><?php the_posts_pagination( array( 'mid_size' => 1, 'prev_text' => __( '← Previous', 'vector-arcade' ), 'next_text' => __( 'Next →', 'vector-arcade' ) ) ); ?></div>
		<?php else : ?><div class="va-empty-state"><p><?php esc_html_e( 'No entries found in this sector.', 'vector-arcade' ); ?></p></div><?php endif; ?>
	</div>
</main>
<?php get_footer(); ?>
