<?php
/**
 * Vector Arcade theme functions.
 *
 * @package Vector_Arcade
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Resolve the visitor's selected interface language. */
function vector_arcade_current_language() {
	$allowed = array( 'en', 'fr' );
	if ( isset( $_GET['va_lang'] ) && is_string( $_GET['va_lang'] ) ) {
		$requested = sanitize_key( wp_unslash( $_GET['va_lang'] ) );
		if ( in_array( $requested, $allowed, true ) ) {
			return $requested;
		}
	}
	if ( isset( $_COOKIE['va_language'] ) && is_string( $_COOKIE['va_language'] ) ) {
		$cookie_language = sanitize_key( wp_unslash( $_COOKIE['va_language'] ) );
		if ( in_array( $cookie_language, $allowed, true ) ) {
			return $cookie_language;
		}
	}
	$site_locale = (string) get_option( 'WPLANG', 'en_US' );
	return 0 === strpos( $site_locale, 'fr' ) ? 'fr' : 'en';
}

/** Apply the visitor's choice to front-end WordPress and theme translations. */
function vector_arcade_filter_frontend_locale( $locale ) {
	if ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return $locale;
	}
	return 'fr' === vector_arcade_current_language() ? 'fr_FR' : 'en_US';
}
add_filter( 'locale', 'vector_arcade_filter_frontend_locale', 20 );

/** Persist an explicit language selection for subsequent page views. */
function vector_arcade_persist_language_choice() {
	if ( ! isset( $_GET['va_lang'] ) || ! is_string( $_GET['va_lang'] ) ) {
		return;
	}
	$language = sanitize_key( wp_unslash( $_GET['va_lang'] ) );
	if ( ! in_array( $language, array( 'en', 'fr' ), true ) ) {
		return;
	}
	$cookie_path = defined( 'COOKIEPATH' ) && COOKIEPATH ? COOKIEPATH : '/';
	$cookie_domain = defined( 'COOKIE_DOMAIN' ) ? COOKIE_DOMAIN : '';
	setcookie(
		'va_language',
		$language,
		array(
			'expires'  => time() + YEAR_IN_SECONDS,
			'path'     => $cookie_path,
			'domain'   => $cookie_domain,
			'secure'   => is_ssl(),
			'httponly' => true,
			'samesite' => 'Lax',
		)
	);
	$_COOKIE['va_language'] = $language;
}
add_action( 'init', 'vector_arcade_persist_language_choice', 1 );

/** Build a language-switch URL without discarding the current page or query. */
function vector_arcade_language_url( $language ) {
	$url = remove_query_arg( 'va_lang' );
	return add_query_arg( 'va_lang', 'fr' === $language ? 'fr' : 'en', $url );
}

/** Render a compact, accessible English/French language selector. */
function vector_arcade_language_switcher() {
	$current = vector_arcade_current_language();
	echo '<div class="va-language-switcher" role="group" aria-label="' . esc_attr__( 'Choose language', 'vector-arcade' ) . '">';
	foreach ( array( 'en' => 'EN', 'fr' => 'FR' ) as $language => $label ) {
		$active = $current === $language;
		printf(
			'<a href="%1$s" lang="%2$s" hreflang="%2$s"%3$s aria-label="%4$s">%5$s</a>',
			esc_url( vector_arcade_language_url( $language ) ),
			esc_attr( 'fr' === $language ? 'fr' : 'en' ),
			$active ? ' class="is-active" aria-current="true"' : '',
			esc_attr( 'fr' === $language ? __( 'Switch to French', 'vector-arcade' ) : __( 'Switch to English', 'vector-arcade' ) ),
			esc_html( $label )
		);
	}
	echo '</div>';
}

function vector_arcade_setup() {
	load_theme_textdomain( 'vector-arcade', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array(
		'height'      => 120,
		'width'       => 360,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'editor-style.css' );

	register_nav_menus( array(
		'primary' => __( 'Primary navigation', 'vector-arcade' ),
		'footer'  => __( 'Footer navigation', 'vector-arcade' ),
	) );

	add_image_size( 'vector-arcade-card', 760, 475, true );
}
add_action( 'after_setup_theme', 'vector_arcade_setup' );

function vector_arcade_assets() {
	$theme_version = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'vector-arcade-style', get_stylesheet_uri(), array(), $theme_version );
	wp_enqueue_script( 'vector-arcade-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), $theme_version, true );
}
add_action( 'wp_enqueue_scripts', 'vector_arcade_assets' );

function vector_arcade_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Footer widget area', 'vector-arcade' ),
		'id'            => 'footer-1',
		'description'   => __( 'Optional widgets displayed above the footer credits.', 'vector-arcade' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'vector_arcade_widgets_init' );

function vector_arcade_customize_register( $wp_customize ) {
	$wp_customize->add_section( 'vector_arcade_hero', array(
		'title'       => __( 'Vector Arcade — Homepage hero', 'vector-arcade' ),
		'description' => __( 'Edit the text and primary link shown in the homepage hero.', 'vector-arcade' ),
		'priority'    => 30,
	) );

	$settings = array(
		'va_hero_eyebrow' => array(
			'label'   => __( 'Eyebrow text', 'vector-arcade' ),
			'default' => __( 'WORDPRESS THEME / INTERACTIVE DEMO', 'vector-arcade' ),
			'type'    => 'text',
		),
		'va_hero_title' => array(
			'label'   => __( 'Hero heading', 'vector-arcade' ),
			'default' => __( 'A DEVELOPER PORTFOLIO.', 'vector-arcade' ),
			'type'    => 'text',
		),
		'va_hero_highlight' => array(
			'label'   => __( 'Highlighted hero text', 'vector-arcade' ),
			'default' => __( 'WITH ARCADE ENERGY.', 'vector-arcade' ),
			'type'    => 'text',
		),
		'va_hero_description' => array(
			'label'   => __( 'Hero description', 'vector-arcade' ),
			'default' => __( 'A responsive WordPress theme with original neon vector artwork, a bilingual interface and a clear technical story.', 'vector-arcade' ),
			'type'    => 'textarea',
		),
		'va_hero_button_text' => array(
			'label'   => __( 'Primary button label', 'vector-arcade' ),
			'default' => __( 'EXPLORE THE BUILD', 'vector-arcade' ),
			'type'    => 'text',
		),
		'va_hero_button_url' => array(
			'label'   => __( 'Primary button URL', 'vector-arcade' ),
			'default' => '#features',
			'type'    => 'url',
		),
	);

	foreach ( $settings as $id => $setting ) {
		$wp_customize->add_setting( $id, array(
			'default'           => $setting['default'],
			'sanitize_callback' => 'url' === $setting['type'] ? 'esc_url_raw' : ( 'textarea' === $setting['type'] ? 'sanitize_textarea_field' : 'sanitize_text_field' ),
			'transport'         => 'refresh',
		) );
		$wp_customize->add_control( $id, array(
			'label'    => $setting['label'],
			'section'  => 'vector_arcade_hero',
			'type'     => $setting['type'],
			'priority' => 10,
		) );
	}
}
add_action( 'customize_register', 'vector_arcade_customize_register' );

/** Return a useful URL for the main feed button. */
function vector_arcade_feed_url() {
	$posts_page = (int) get_option( 'page_for_posts' );
	if ( $posts_page ) {
		return get_permalink( $posts_page );
	}
	return get_post_type_archive_link( 'post' ) ? get_post_type_archive_link( 'post' ) : home_url( '/' );
}

/** Provide an informative navigation when no menu has been assigned yet. */
function vector_arcade_menu_fallback() {
	$items = array(
		__( 'Overview', 'vector-arcade' )   => home_url( '/#top' ),
		__( 'Features', 'vector-arcade' )   => home_url( '/#features' ),
		__( 'Technical', 'vector-arcade' )  => home_url( '/#technical' ),
		__( 'Journal', 'vector-arcade' )    => home_url( '/#latest' ),
	);
	echo '<ul class="va-menu">';
	foreach ( $items as $label => $url ) {
		echo '<li><a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a></li>';
	}
	echo '</ul>';
}

/** Readable date and category metadata for a post card. */
function vector_arcade_card_meta() {
	$categories = get_the_category();
	if ( ! empty( $categories ) ) {
		$category = $categories[0];
		echo '<span class="va-card-category">' . esc_html( $category->name ) . '</span><span aria-hidden="true">/</span>';
	}
	echo '<time datetime="' . esc_attr( get_the_date( DATE_W3C ) ) . '">' . esc_html( get_the_date() ) . '</time>';
}

/** Ensure excerpts used in cards are brief and free of markup. */
function vector_arcade_card_excerpt( $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$excerpt = get_the_excerpt( $post_id );
	return wp_trim_words( wp_strip_all_tags( $excerpt ), 22, '…' );
}
