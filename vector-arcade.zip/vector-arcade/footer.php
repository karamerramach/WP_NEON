<?php
/** Site footer. @package Vector_Arcade */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<footer class="va-footer">
	<div class="va-wrap va-footer-main">
		<div>
			<p class="va-footer-title"><?php bloginfo( 'name' ); ?></p>
			<p class="va-footer-copy"><?php echo esc_html( get_bloginfo( 'description' ) ? get_bloginfo( 'description' ) : __( 'A WordPress theme built to be explored.', 'vector-arcade' ) ); ?></p>
		</div>
		<?php if ( has_nav_menu( 'footer' ) ) : ?>
			<nav aria-label="<?php esc_attr_e( 'Footer navigation', 'vector-arcade' ); ?>">
				<?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'menu_class' => 'va-footer-menu', 'depth' => 1 ) ); ?>
			</nav>
		<?php endif; ?>
	</div>
	<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
		<div class="va-wrap va-footer-widgets">
			<?php dynamic_sidebar( 'footer-1' ); ?>
		</div>
	<?php endif; ?>
	<div class="va-wrap va-footer-bottom">
		<span><?php echo esc_html( sprintf( __( '© %1$s %2$s. Built with WordPress.', 'vector-arcade' ), gmdate( 'Y' ), get_bloginfo( 'name' ) ) ); ?></span>
		<a href="#top"><?php esc_html_e( 'Back to top ↑', 'vector-arcade' ); ?></a>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
