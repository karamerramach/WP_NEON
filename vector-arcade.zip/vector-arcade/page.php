<?php
/** Page template. @package Vector_Arcade */
get_header();
?>
<main id="content" class="va-main">
	<div class="va-wrap">
		<?php while ( have_posts() ) : the_post(); ?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'va-entry' ); ?>>
				<header class="va-entry-header"><span class="va-eyebrow"><?php esc_html_e( 'New sector unlocked', 'vector-arcade' ); ?></span><h1 class="va-entry-title"><?php the_title(); ?></h1></header>
				<?php if ( has_post_thumbnail() ) : ?><div class="va-entry-featured"><?php the_post_thumbnail( 'large' ); ?></div><?php endif; ?>
				<div class="va-entry-content"><?php the_content(); wp_link_pages(); ?></div>
			</article>
		<?php endwhile; ?>
	</div>
</main>
<?php get_footer(); ?>
