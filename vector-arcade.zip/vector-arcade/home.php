<?php
/** Posts index template. @package Vector_Arcade */
get_header();
?>
<main id="content" class="va-main">
	<div class="va-wrap">
		<header class="va-page-header"><span class="va-eyebrow"><?php esc_html_e( 'The feed', 'vector-arcade' ); ?></span><h1 class="va-page-title"><?php echo esc_html( get_the_title( (int) get_option( 'page_for_posts' ) ) ?: __( 'Latest transmissions', 'vector-arcade' ) ); ?></h1></header>
		<?php if ( have_posts() ) : ?>
			<div class="va-post-grid"><?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/content', 'card' ); endwhile; ?></div>
			<div class="va-pagination"><?php the_posts_pagination( array( 'mid_size' => 1, 'prev_text' => __( '← Previous', 'vector-arcade' ), 'next_text' => __( 'Next →', 'vector-arcade' ) ) ); ?></div>
		<?php else : ?><div class="va-empty-state"><p><?php esc_html_e( 'Nothing on this frequency yet. Check back soon.', 'vector-arcade' ); ?></p></div><?php endif; ?>
	</div>
</main>
<?php get_footer(); ?>
