<?php
/** Single post template. @package Vector_Arcade */
get_header();
?>
<main id="content" class="va-main">
	<div class="va-wrap">
		<?php while ( have_posts() ) : the_post(); ?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'va-entry' ); ?>>
				<header class="va-entry-header"><span class="va-eyebrow"><?php esc_html_e( 'Transmission received', 'vector-arcade' ); ?></span><h1 class="va-entry-title"><?php the_title(); ?></h1><div class="va-entry-meta"><span><?php echo esc_html( get_the_date() ); ?></span><span><?php the_category( ' / ' ); ?></span><span><?php the_author_posts_link(); ?></span></div></header>
				<?php if ( has_post_thumbnail() ) : ?><div class="va-entry-featured"><?php the_post_thumbnail( 'large' ); ?></div><?php endif; ?>
				<div class="va-entry-content"><?php the_content(); wp_link_pages(); ?></div>
				<div class="va-post-navigation"><?php the_post_navigation( array( 'prev_text' => '<span aria-hidden="true">←</span> %title', 'next_text' => '%title <span aria-hidden="true">→</span>' ) ); ?></div>
			</article>
			<?php if ( comments_open() || get_comments_number() ) : ?><div class="va-comments"><?php comments_template(); ?></div><?php endif; ?>
		<?php endwhile; ?>
	</div>
</main>
<?php get_footer(); ?>
