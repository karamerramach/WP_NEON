<?php
/** Site header. @package Vector_Arcade */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="va-skip-link" href="#content"><?php esc_html_e( 'Skip to content', 'vector-arcade' ); ?></a>
<header class="va-header" id="top">
	<div class="va-wrap va-header-inner">
		<a class="va-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<span class="va-brand-mark" aria-hidden="true">V/A</span>
			<?php endif; ?>
			<span class="va-brand-copy">
				<span class="va-site-title"><?php bloginfo( 'name' ); ?></span>
				<?php if ( get_bloginfo( 'description' ) ) : ?>
					<span class="va-site-tagline"><?php bloginfo( 'description' ); ?></span>
				<?php else : ?>
					<span class="va-site-tagline"><?php esc_html_e( 'A WordPress theme / built to be explored', 'vector-arcade' ); ?></span>
				<?php endif; ?>
			</span>
		</a>

		<button class="va-menu-toggle" type="button" aria-controls="va-primary-navigation" aria-expanded="false">
			<span></span><span></span><span></span>
			<span class="screen-reader-text"><?php esc_html_e( 'Toggle navigation', 'vector-arcade' ); ?></span>
		</button>

		<div class="va-nav-wrap" id="va-primary-navigation">
			<nav class="va-nav" aria-label="<?php esc_attr_e( 'Primary navigation', 'vector-arcade' ); ?>">
				<?php wp_nav_menu( array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_id'        => 'primary-menu',
					'menu_class'     => 'va-menu',
					'fallback_cb'    => 'vector_arcade_menu_fallback',
				) ); ?>
			</nav>
			<?php vector_arcade_language_switcher(); ?>
			<a class="va-header-cta" href="<?php echo esc_url( home_url( '/#technical' ) ); ?>"><?php esc_html_e( 'Technical notes', 'vector-arcade' ); ?></a>
		</div>
	</div>
</header>
