<?php
/** Homepage template. @package Vector_Arcade */
get_header();
$hero_eyebrow      = get_theme_mod( 'va_hero_eyebrow', __( 'WORDPRESS THEME / INTERACTIVE DEMO', 'vector-arcade' ) );
$hero_title        = get_theme_mod( 'va_hero_title', __( 'A DEVELOPER PORTFOLIO.', 'vector-arcade' ) );
$hero_highlight    = get_theme_mod( 'va_hero_highlight', __( 'WITH ARCADE ENERGY.', 'vector-arcade' ) );
$hero_description = get_theme_mod( 'va_hero_description', __( 'A responsive WordPress theme with original neon vector artwork, a bilingual interface and a clear technical story.', 'vector-arcade' ) );
$hero_button_text  = get_theme_mod( 'va_hero_button_text', __( 'EXPLORE THE BUILD', 'vector-arcade' ) );
$hero_button_url   = get_theme_mod( 'va_hero_button_url', '#features' );
?>
<main id="content">
	<section class="va-hero">
		<div class="va-wrap va-hero-grid">
			<div class="va-hero-copy">
				<span class="va-eyebrow"><?php echo esc_html( $hero_eyebrow ); ?></span>
				<h1><?php echo esc_html( $hero_title ); ?><span class="va-neon"><?php echo esc_html( $hero_highlight ); ?></span></h1>
				<p class="va-hero-description"><?php echo esc_html( $hero_description ); ?></p>
				<div class="va-hero-actions">
					<a class="va-button" href="<?php echo esc_url( $hero_button_url ); ?>"><?php echo esc_html( $hero_button_text ); ?></a>
					<a class="va-button va-button--ghost" href="#technical"><?php esc_html_e( 'View technical notes', 'vector-arcade' ); ?></a>
				</div>
				<div class="va-hero-meta">
					<span><i class="va-status-dot" aria-hidden="true"></i><?php esc_html_e( 'WordPress theme / online demo', 'vector-arcade' ); ?></span>
					<span><?php esc_html_e( 'English + Français', 'vector-arcade' ); ?></span>
				</div>
			</div>
			<div class="va-hero-art">
				<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/neon-arcade.svg' ); ?>" alt="<?php esc_attr_e( 'Original neon vector illustration of a retro arcade machine surrounded by a glowing perspective grid and geometric stars', 'vector-arcade' ); ?>" fetchpriority="high">
				<span class="va-hero-corner" aria-hidden="true"><?php esc_html_e( 'Built to be explored', 'vector-arcade' ); ?></span>
			</div>
		</div>
		<div class="va-scanline" aria-hidden="true"></div>
	</section>

	<section class="va-signal-strip" aria-label="<?php esc_attr_e( 'Theme highlights', 'vector-arcade' ); ?>">
		<div class="va-wrap va-signal-inner">
			<div class="va-signal-item"><span class="va-signal-number">01</span><span class="va-signal-label"><strong><?php esc_html_e( 'WordPress-native', 'vector-arcade' ); ?></strong><?php esc_html_e( 'PHP templates and theme hooks', 'vector-arcade' ); ?></span></div>
			<div class="va-signal-item"><span class="va-signal-number">02</span><span class="va-signal-label"><strong><?php esc_html_e( 'Bilingual interface', 'vector-arcade' ); ?></strong><?php esc_html_e( 'English and French selector', 'vector-arcade' ); ?></span></div>
			<div class="va-signal-item"><span class="va-signal-number">03</span><span class="va-signal-label"><strong><?php esc_html_e( 'Responsive by design', 'vector-arcade' ); ?></strong><?php esc_html_e( 'Keyboard and reduced-motion support', 'vector-arcade' ); ?></span></div>
		</div>
	</section>

	<section class="va-section" id="features">
		<div class="va-wrap">
			<div class="va-section-heading">
				<div><span class="va-eyebrow"><?php esc_html_e( 'A closer look', 'vector-arcade' ); ?></span><h2><?php esc_html_e( 'Built for the ', 'vector-arcade' ); ?><span><?php esc_html_e( 'real web', 'vector-arcade' ); ?></span></h2></div>
				<a class="va-section-link" href="#technical"><?php esc_html_e( 'Explore architecture →', 'vector-arcade' ); ?></a>
			</div>
			<div class="va-capability-grid">
				<article class="va-capability-card"><span class="va-capability-index">01 / CONTENT</span><h3><?php esc_html_e( 'Editorial templates', 'vector-arcade' ); ?></h3><p><?php esc_html_e( 'Purpose-built layouts for the front page, posts, pages, archives, search results and 404 states.', 'vector-arcade' ); ?></p><a href="#latest"><?php esc_html_e( 'Browse content layouts', 'vector-arcade' ); ?> <span aria-hidden="true">→</span></a></article>
				<article class="va-capability-card"><span class="va-capability-index">02 / LANGUAGE</span><h3><?php esc_html_e( 'English + French', 'vector-arcade' ); ?></h3><p><?php esc_html_e( 'A visible EN / FR selector remembers the visitor’s choice and loads the theme’s French translation.', 'vector-arcade' ); ?></p><a href="#top"><?php esc_html_e( 'Try the language switcher', 'vector-arcade' ); ?> <span aria-hidden="true">→</span></a></article>
				<article class="va-capability-card"><span class="va-capability-index">03 / EXPERIENCE</span><h3><?php esc_html_e( 'Accessible interaction', 'vector-arcade' ); ?></h3><p><?php esc_html_e( 'Responsive navigation, visible focus states, semantic landmarks and reduced-motion handling.', 'vector-arcade' ); ?></p><a href="#technical"><?php esc_html_e( 'Review implementation', 'vector-arcade' ); ?> <span aria-hidden="true">→</span></a></article>
			</div>
		</div>
	</section>

	<section class="va-section va-section--technical" id="technical">
		<div class="va-wrap va-technical-grid">
			<div><span class="va-eyebrow"><?php esc_html_e( 'Under the hood', 'vector-arcade' ); ?></span><h2><?php esc_html_e( 'A practical WordPress build.', 'vector-arcade' ); ?></h2><p><?php esc_html_e( 'The visual layer is backed by conventional WordPress theme APIs rather than a static mockup. Content remains editable in the dashboard.', 'vector-arcade' ); ?></p></div>
			<div class="va-tech-list">
				<div><strong>01</strong><span><b><?php esc_html_e( 'PHP theme templates', 'vector-arcade' ); ?></b><small><?php esc_html_e( 'Template hierarchy, template parts, hooks and Customizer settings.', 'vector-arcade' ); ?></small></span></div>
				<div><strong>02</strong><span><b><?php esc_html_e( 'WordPress localization', 'vector-arcade' ); ?></b><small><?php esc_html_e( 'Translation-ready strings, French MO catalog and visitor language preference.', 'vector-arcade' ); ?></small></span></div>
				<div><strong>03</strong><span><b><?php esc_html_e( 'Frontend engineering', 'vector-arcade' ); ?></b><small><?php esc_html_e( 'Custom CSS properties, responsive layouts and a small vanilla JavaScript navigation controller.', 'vector-arcade' ); ?></small></span></div>
				<div><strong>04</strong><span><b><?php esc_html_e( 'Original vector assets', 'vector-arcade' ); ?></b><small><?php esc_html_e( 'Scalable local SVG artwork with no remote font or image dependency.', 'vector-arcade' ); ?></small></span></div>
			</div>
		</div>
	</section>

	<section class="va-section" id="latest">
		<div class="va-wrap">
			<div class="va-section-heading">
				<div><span class="va-eyebrow"><?php esc_html_e( 'Content system', 'vector-arcade' ); ?></span><h2><?php esc_html_e( 'Ready for your ', 'vector-arcade' ); ?><span><?php esc_html_e( 'work', 'vector-arcade' ); ?></span></h2></div>
				<a class="va-section-link" href="<?php echo esc_url( vector_arcade_feed_url() ); ?>"><?php esc_html_e( 'Open the journal →', 'vector-arcade' ); ?></a>
			</div>
			<div class="va-post-grid">
				<?php
				$va_latest = new WP_Query( array(
					'post_type'           => 'post',
					'post_status'         => 'publish',
					'posts_per_page'      => 3,
					'ignore_sticky_posts' => true,
				) );
				if ( $va_latest->have_posts() ) :
					while ( $va_latest->have_posts() ) :
						$va_latest->the_post();
						get_template_part( 'template-parts/content', 'card' );
					endwhile;
					wp_reset_postdata();
				else :
					$demo_cards = array(
						array( '01 / THEME', __( 'A complete theme system', 'vector-arcade' ), __( 'A custom front page, reusable template parts, archive layouts and an editable WordPress content layer.', 'vector-arcade' ), '#features' ),
						array( '02 / LOCALE', __( 'A visitor-controlled language', 'vector-arcade' ), __( 'English and French interface strings, a persistent language choice and localized WordPress output.', 'vector-arcade' ), '#top' ),
						array( '03 / FRONTEND', __( 'A responsive interface', 'vector-arcade' ), __( 'Mobile navigation, semantic markup, scalable vector artwork and reduced-motion support.', 'vector-arcade' ), '#technical' ),
					);
					foreach ( $demo_cards as $card ) :
						?>
						<article class="va-post-card va-demo-card"><div class="va-card-body"><div class="va-card-meta"><span class="va-card-category"><?php echo esc_html( $card[0] ); ?></span></div><h3 class="va-card-title"><a href="<?php echo esc_url( $card[3] ); ?>"><?php echo esc_html( $card[1] ); ?></a></h3><p class="va-card-excerpt"><?php echo esc_html( $card[2] ); ?></p><a class="va-card-read" href="<?php echo esc_url( $card[3] ); ?>"><?php esc_html_e( 'Explore this feature', 'vector-arcade' ); ?></a></div></article>
						<?php
					endforeach;
				endif;
				?>
			</div>
		</div>
	</section>

	<?php if ( is_page() && have_posts() ) : ?>
		<?php while ( have_posts() ) : the_post(); ?>
			<?php if ( trim( get_the_content() ) ) : ?>
				<section class="va-section" style="padding-top:0"><div class="va-wrap va-entry-content"><?php the_content(); ?></div></section>
			<?php endif; ?>
		<?php endwhile; ?>
	<?php endif; ?>
</main>
<?php get_footer(); ?>
