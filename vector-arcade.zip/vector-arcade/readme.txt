VECTOR ARCADE 1.1.0
===================

A bilingual, responsive WordPress theme with an arcade-inspired neon vector identity. The front page is structured as a browsable technical showcase, so the theme can be evaluated before editorial content is added.

INSTALLATION
------------
1. In WordPress, open Appearance > Themes > Add New > Upload Theme.
2. Upload vector-arcade.zip and select Install Now.
3. Activate Vector Arcade.
4. Open Appearance > Customize > Vector Arcade — Homepage hero to edit the main heading, description and button.
5. Set the site name and tagline under Settings > General, and add a logo under Appearance > Customize > Site Identity.
6. Assign a custom menu under Appearance > Menus. If no menu is assigned, the theme displays a useful section-navigation fallback.
7. Add posts to populate the journal section. With no posts, the front page displays built-in feature cards so the site remains browsable immediately after activation.

LANGUAGES
---------
The header includes an EN / FR selector. The visitor's choice is stored in a first-party cookie and used to load the English or French WordPress locale on front-end requests. The French theme catalog is included in languages/fr_FR.mo, with editable source in languages/fr_FR.po.

The selector translates theme interface strings and WordPress strings supplied by the installed language pack. It does not automatically translate editorial content, manually named menus, or text saved in Customizer fields. For fully translated posts, pages and menus, use a multilingual content plugin such as Polylang or WPML and maintain the corresponding translated content.

HOMEPAGE AND CUSTOMIZATION
--------------------------
The front page includes an introduction, feature cards, technical overview, and a journal area. If the site has no posts, the journal area shows informative theme feature cards instead of empty placeholders. The homepage hero fields remain editable through the Customizer.

FEATURES
--------
- Original scalable SVG hero illustration; no remote font or image service dependency.
- English/French language switcher with persistent visitor preference.
- French gettext catalog (.po and compiled .mo).
- Responsive navigation with keyboard support.
- Custom logo, title, tagline and configurable hero copy.
- Posts, pages, categories, tags, search, comments and 404 templates.
- Featured-image post cards, Gutenberg wide/full-width support and editor styling.
- Footer navigation and optional footer widget area.
- Reduced-motion support and visible keyboard focus states.
- Semantic landmarks and accessible link labels.

REQUIREMENTS
------------
- WordPress 6.2 or newer.
- PHP 7.4 or newer.

DEMO
----
Open the accompanying vector-arcade-demo/index.html in a browser for a self-contained English/French preview. It uses local CSS and SVG assets and does not require WordPress or an internet connection.

LICENSE
-------
Theme code and original artwork are provided under GPL-2.0-or-later.
