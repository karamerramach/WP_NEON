<?php
/** Comments template. @package Vector_Arcade */
if ( post_password_required() ) { return; }
?>
<div id="comments" class="comments-area">
	<?php if ( have_comments() ) : ?>
		<h2><?php printf( esc_html( _nx( 'One response', '%1$s responses', get_comments_number(), 'comments title', 'vector-arcade' ) ), esc_html( number_format_i18n( get_comments_number() ) ) ); ?></h2>
		<ol class="comment-list"><?php wp_list_comments( array( 'style' => 'ol', 'short_ping' => true, 'avatar_size' => 40 ) ); ?></ol>
		<?php the_comments_pagination(); ?>
	<?php endif; ?>
	<?php if ( ! comments_open() && get_comments_number() ) : ?><p><?php esc_html_e( 'Comments are closed.', 'vector-arcade' ); ?></p><?php endif; ?>
	<?php comment_form(); ?>
</div>
