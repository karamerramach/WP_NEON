<?php
/** Search results template. @package Vector_Arcade */
get_header();
?>
<main id="content" class="va-main">
	<div class="va-wrap">
		<header class="va-page-header"><span class="va-eyebrow"><?php esc_html_e( 'Signal search', 'vector-arcade' ); ?></span><h1 class="va-page-title"><?php esc_html_e( 'Search results', 'vector-arcade' ); ?></h1><p class="va-page-description"><?php printf( esc_html__( 'You searched for: %s', 'vector-arcade' ), '<strong>' . esc_html( get_search_query() ) . '</strong>' ); ?></p><?php get_search_form(); ?></header>
		<?php if ( have_posts() ) : ?><div class="va-post-grid"><?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/content', 'card' ); endwhile; ?></div><div class="va-pagination"><?php the_posts_pagination(); ?></div><?php else : ?><div class="va-empty-state"><p><?php esc_html_e( 'No matches found. Try another search frequency.', 'vector-arcade' ); ?></p></div><?php endif; ?>
	</div>
</main>
<?php get_footer(); ?>
